var StateEnum = 
{
  InitializeData: 0,
  CreateTopics: 1,
  
  SelecTopics:2,
  FirstSelectTopics: 3,
  SecondSelectTopics: 4,
  ThirdSelectTopics: 5,

  ReSelectTopics: 6,
  ReFirstSelectTopics: 7,
  ReSecondSelectTopics: 8,
  ReThirdSelectTopics: 9,

  ReDetermineGroups: 10,
  Scoring: 11
}

var global.CurrentState = StateEnum.InitializeData


