import WyvonjTooltip from './WyvonjTooltip.vue';

export default function install(Vue) {
  Vue.component('wyvonj-tooltip', WyvonjTooltip);
}
