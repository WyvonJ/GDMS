//从store的state中派生出一些状态
//如果有多个组件需要用同一计算属性，要么复制这个函数
//或者抽取到一个共享函数然后在多处导入，十分不理想
//getters可认为是store的计算属性
export default{
	
}